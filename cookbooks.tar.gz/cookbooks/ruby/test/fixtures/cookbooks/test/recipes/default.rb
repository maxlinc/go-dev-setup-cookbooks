execute 'apt-get update' if platform_family?('debian')
