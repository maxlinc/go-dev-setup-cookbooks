require 'serverspec'

# Required by serverspec
set :backend, :exec
