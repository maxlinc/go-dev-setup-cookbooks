opscode-chef-cookbook-sass
==========================

Installs SASS from http://sass-lang.com/