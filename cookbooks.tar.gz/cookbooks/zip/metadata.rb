name             "zip"
maintainer       "Phil Cohen"
maintainer_email "github@phlippers.net"
license          "MIT"
description      "Installs zip and unzip"
version          "1.1.0"

recipe "zip", "Installs zip and unzip"

supports "ubuntu"
supports "redhat"
supports "centos"
