name             "rake"
maintainer       "Ernie Brodeur"
maintainer_email "ebrodeur@ujami.net"
license          "Beer-ware rv42"
description      "Installs/Configures rake"
long_description IO.read(File.join(File.dirname(__FILE__), 'README.md'))
version          "0.1.1"
