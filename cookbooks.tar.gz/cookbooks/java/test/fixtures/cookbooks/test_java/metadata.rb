name             'test_java'
maintainer       'test cookbook'
license          'All rights reserved'
description      'A test cookbook to land testing jar for java cookbook'
version          '0.1.0'

