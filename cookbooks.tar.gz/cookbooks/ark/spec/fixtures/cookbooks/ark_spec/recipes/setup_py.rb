ark 'test_setup_py' do
  url 'https://codeload.github.com/s3tools/s3cmd/tar.gz/master'
  extension 'tar.gz'
  action :setup_py
end
